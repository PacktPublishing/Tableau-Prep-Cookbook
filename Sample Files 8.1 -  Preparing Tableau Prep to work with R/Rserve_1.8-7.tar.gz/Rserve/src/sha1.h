#ifndef SHA1_H__
#define SHA1_H__

void sha1hash(const char *buf, int len, unsigned char hash[20]);

#endif
